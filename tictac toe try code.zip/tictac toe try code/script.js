const gameCells = document.querySelectorAll('.cell');
const restartBtn = document.querySelector('.restartBtn');

let currentPlayer = 'X';
let playerTurn = currentPlayer;

const startGame = () => {
    gameCells.forEach(cell => {
        cell.textContent = ''; // Clear any previous content
        cell.classList.remove('disabled'); // Enable cells if disabled
        cell.addEventListener('click', handleClick, { once: true });
    });
    playerTurn = currentPlayer;
};

const handleClick = (e) => {
    e.target.textContent = playerTurn;
    if (checkWin()) {
        console.log(`${playerTurn} is a Winner!`);
        disableCells();
    } else if (checkTie()) {
        console.log("It's a Tie!");
        disableCells();
    } else {
        changePlayerTurn();
    }
};

// Function to change player turn
const changePlayerTurn = () => {
    playerTurn = playerTurn === 'X' ? 'O' : 'X';
};

// Function to check for a win
const checkWin = () => {
    const winningConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];
    return winningConditions.some(condition => {
        const [a, b, c] = condition;
        return gameCells[a].textContent &&
               gameCells[a].textContent === gameCells[b].textContent &&
               gameCells[a].textContent === gameCells[c].textContent;
    });
};

// Function to check for a tie
const checkTie = () => {
    return [...gameCells].every(cell => cell.textContent !== '') && !checkWin();
};

// Function to disable the board after a win or tie
const disableCells = () => {
    gameCells.forEach(cell => {
        cell.removeEventListener('click', handleClick);
        cell.classList.add('disabled');
    });
};

// Event listener for the restart button
restartBtn.addEventListener('click', startGame);

// Start the game initially
startGame();
